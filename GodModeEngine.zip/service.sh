#!/system/bin/sh
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 2; done

# Force Performance Governor on all cores
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    echo "performance" > $cpu
done

# Disable Core Parking (Keeps all brains awake)
echo 0 > /sys/module/core_ctl/parameters/is_active

# Boost GPU to max frequencies
echo "performance" > /sys/class/kgsl/kgsl-3d0/devfreq/governor

log -p i -t SuperROM "[MODULE 3] God-Mode Performance ONLINE."
