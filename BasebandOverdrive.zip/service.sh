#!/system/bin/sh
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 2; done

# Inject Network Properties
resetprop persist.radio.ntn.enable true
resetprop persist.vendor.radio.force_on_dc true
resetprop ro.telephony.default_network 33

# Load TCP BBR for hyper-fast data
modprobe tcp_bbr
sysctl -w net.ipv4.tcp_congestion_control=bbr
sysctl -w net.core.default_qdisc=fq

log -p i -t SuperROM "[MODULE 4] Baseband Overdrive ONLINE."
