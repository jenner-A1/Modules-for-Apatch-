#!/system/bin/sh
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 2; done

# Set conservative scaling
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    echo "schedutil" > $cpu
done

# Allow deeper sleep states
echo 1 > /sys/module/lpm_levels/parameters/sleep_disabled

log -p i -t SuperROM "[MODULE 10] Cold-Core Battery Saver ONLINE."
