#!/system/bin/sh
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 2; done

# Disable MAC Randomization for stable Wi-Fi monitoring
settings put global wifi_connected_mac_randomization_enabled 0

# Enable USB HID Gadget capabilities (BadUSB/DuckDucky emulation)
setprop sys.usb.configfs 1
echo "" > /config/usb_gadget/g1/UDC
echo 0x1d6b > /config/usb_gadget/g1/idVendor
echo 0x0104 > /config/usb_gadget/g1/idProduct

log -p i -t SuperROM "[MODULE 7] NetHunter Kernel Infrastructure ONLINE."
